import HeaderBox from '@/components/HeaderBox'
import React from 'react'

const Transfer = () => {
  return (
    <section className='payment-transfer'>
        <HeaderBox
            title='Payment Transfer'
            subtext='Please provide any specitic details.'
        />
    </section>
  )
}

export default Transfer