(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(root)_layout_tsx_8129cb._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(root)_layout_tsx_8129cb._.js",
  "chunks": [
    "static/chunks/node_modules_next_67276f._.js",
    "static/chunks/node_modules_react-icons_hi2_index_mjs_d1d125._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_7f7be9._.js",
    "static/chunks/src_faac3d._.js"
  ],
  "source": "dynamic"
});
