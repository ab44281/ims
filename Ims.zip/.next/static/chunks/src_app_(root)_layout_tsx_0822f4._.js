(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(root)_layout_tsx_0822f4._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(root)_layout_tsx_0822f4._.js",
  "chunks": [
    "static/chunks/node_modules_next_84c963._.js",
    "static/chunks/node_modules_react-icons_hi2_index_mjs_d1d125._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_4b54e1._.js",
    "static/chunks/src_d8fa3b._.js"
  ],
  "source": "dynamic"
});
