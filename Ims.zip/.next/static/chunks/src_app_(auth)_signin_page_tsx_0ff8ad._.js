(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_signin_page_tsx_0ff8ad._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_signin_page_tsx_0ff8ad._.js",
  "chunks": [
    "static/chunks/node_modules_743390._.js",
    "static/chunks/src_46f8d1._.js"
  ],
  "source": "dynamic"
});
