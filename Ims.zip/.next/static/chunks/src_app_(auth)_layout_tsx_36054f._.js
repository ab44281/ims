(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_layout_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_layout_tsx_36054f._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_ea69ac._.js",
    "static/chunks/src_app_(auth)_layout_tsx_3bad1f._.js"
  ],
  "source": "dynamic"
});
