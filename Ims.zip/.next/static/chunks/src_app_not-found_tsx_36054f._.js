(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_not-found_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_not-found_tsx_36054f._.js",
  "chunks": [
    "static/chunks/_aea32c._.js"
  ],
  "source": "dynamic"
});
