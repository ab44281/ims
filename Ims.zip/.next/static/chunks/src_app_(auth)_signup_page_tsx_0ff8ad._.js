(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_signup_page_tsx_0ff8ad._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_signup_page_tsx_0ff8ad._.js",
  "chunks": [
    "static/chunks/node_modules_88f04d._.js",
    "static/chunks/src_783de6._.js"
  ],
  "source": "dynamic"
});
